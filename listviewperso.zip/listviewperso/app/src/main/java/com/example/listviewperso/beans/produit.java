package com.example.listviewperso.beans;

public class produit {
    private int id,nbrIngredients,photo,comp;
    private String nom,detailsIngred,description,preparation;
    private String duree;


    public produit(String nom,int nbrIngredients,int photo,String duree,String detailsIngred,String description,String preparation){
        this.id=comp++;
        this.nom=nom;
        this.nbrIngredients=nbrIngredients;
        this.photo=photo;
        this.duree=duree;
        this.detailsIngred=detailsIngred;
        this.description=description;
        this.preparation=preparation;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNbrIngredients() {
        return nbrIngredients;
    }

    public void setNbrIngredients(int nbrIngredients) {
        this.nbrIngredients = nbrIngredients;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDetailsIngred() {
        return detailsIngred;
    }

    public void setDetailsIngred(String detailsIngred) {
        this.detailsIngred = detailsIngred;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPreparation() {
        return preparation;
    }

    public void setPreparation(String preparation) {
        this.preparation = preparation;
    }

    public String getDuree() {
        return duree;
    }

    public void setDuree(String duree) {
        this.duree = duree;
    }

    @Override
    public String toString() {
        return "produit{" +
                "id=" + id +
                ", nbrIngredients=" + nbrIngredients +
                ", photo=" + photo +
                ", nom='" + nom + '\'' +
                ", detailsIngred='" + detailsIngred + '\'' +
                ", description='" + description + '\'' +
                ", preparation='" + preparation + '\'' +
                ", duree=" + duree +
                '}';
    }
}
