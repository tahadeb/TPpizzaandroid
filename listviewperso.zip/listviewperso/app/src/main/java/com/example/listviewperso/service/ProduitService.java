package com.example.listviewperso.service;

import com.example.listviewperso.beans.produit;
import com.example.listviewperso.dao.IDao;

import java.util.ArrayList;
import java.util.List;

public class ProduitService implements IDao<produit> {
    private List <produit> pizza;
    private static ProduitService instance;
    private ProduitService(){this.pizza= new ArrayList<>();
    }
    public static ProduitService getInstance(){
        if(instance==null)
            instance = new ProduitService();
        return instance;
    }
    @Override
    public boolean create(produit o) {
        return pizza.add(o);
    }

    @Override
    public boolean update(produit o) {
        return false;
    }

    @Override
    public boolean delete(produit o) {
        return pizza.remove(o);
    }

    @Override
    public produit findById(int id) {
        for(produit p : pizza){
            if(p.getId()==id)
                return p;
        }
        return null;
    }

    @Override
    public List<produit> findAll() {
        return pizza;
    }
}
