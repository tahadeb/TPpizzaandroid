package com.example.listviewperso;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.listviewperso.beans.produit;
import com.example.listviewperso.service.ProduitService;

public class DetailsPizza extends AppCompatActivity {
    private ProduitService ps;
    private ImageView image;
    private TextView desc;
    private TextView nom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_pizza);
        Intent intent = getIntent();
        int id = Integer.parseInt(intent.getStringExtra("idf"));
        ps = ProduitService.getInstance();
        image = findViewById(R.id.photo);
        nom = findViewById(R.id.nom);

        produit p = ps.findById(id);
        image.setImageResource(p.getPhoto());
        desc = findViewById(R.id.desc);
        desc.setText(p.getDescription());
        nom.setText(p.getNom());
    }
}